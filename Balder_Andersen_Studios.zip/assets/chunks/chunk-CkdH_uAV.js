import{r}from"./chunk-D3XAr9d6.js";const o="hr",t=r.forwardRef((e,a)=>r.createElement(o,{...e,ref:a}));t.displayName="Separator";export{t as p};
