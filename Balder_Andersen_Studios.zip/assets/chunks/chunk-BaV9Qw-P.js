import{r as s,j as o}from"./chunk-D3XAr9d6.js";const p=s.forwardRef(({children:r,...a},e)=>o.jsx("p",{...a,ref:e,children:r}));p.displayName="Paragraph";export{p as f};
